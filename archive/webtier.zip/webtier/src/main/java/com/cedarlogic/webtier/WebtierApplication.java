package com.cedarlogic.webtier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebtierApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebtierApplication.class, args);
	}

}
