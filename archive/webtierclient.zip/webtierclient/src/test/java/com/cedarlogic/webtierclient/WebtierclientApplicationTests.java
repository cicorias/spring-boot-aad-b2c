package com.cedarlogic.webtierclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebtierclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
